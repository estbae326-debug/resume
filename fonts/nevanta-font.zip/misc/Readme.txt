Hi thanks for downloading our font :) this is demo version,  Download the commercial version here : https://www.limitype.com


Follow our 
social media:

instagram.com/limitype
https://www.behance.net/limitype
https://www.limitype.com
more information :  https://linktr.ee/limitype

tag us with #limitype to get featured